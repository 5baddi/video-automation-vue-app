![V12 Software](logo.png?raw=true)
# Social Videos Automation
### Videos automation Front-End app that consuming the Videos Automation API to generate videos from content of [V12 Software](https://www.v12software.com).
[Developed by Mohamed BADDI](https://github.com/5baddi)