export const VA = {
    API: "https://dev9-ver2.v12dev.com/api/v1/",
    API2: "https://dev9-ver2.v12dev.com/api/v2/"
}  